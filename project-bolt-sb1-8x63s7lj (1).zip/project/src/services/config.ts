export const GEMINI_API_KEY = 'AIzaSyBtO938KhwoHPobI1zvh9wK6fafeD-Zczk';
export const API_URL = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent';