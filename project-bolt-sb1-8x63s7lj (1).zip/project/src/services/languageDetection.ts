import axios from 'axios';
import { GEMINI_API_KEY, API_URL } from './config';

export const detectLanguage = async (text: string): Promise<string> => {
  try {
    const prompt = `Detect the language of this text and respond with ONLY the ISO 639-1 language code: "${text}"`;
    
    const response = await axios.post(
      `${API_URL}?key=${GEMINI_API_KEY}`,
      {
        contents: [{
          parts: [{ text: prompt }]
        }]
      }
    );

    const detectedCode = response.data.candidates[0].content.parts[0].text.trim().toLowerCase();
    return detectedCode;
  } catch (error) {
    if (axios.isAxiosError(error)) {
      throw new Error(error.response?.data?.error?.message || 'Language detection failed');
    }
    throw error;
  }
};