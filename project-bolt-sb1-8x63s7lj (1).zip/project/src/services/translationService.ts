import axios from 'axios';
import { TranslationResponse } from '../types';
import { GEMINI_API_KEY, API_URL } from '../config/constants';
import { detectLanguage } from './languageDetection';

export const translateText = async (
  text: string,
  fromLang: string,
  toLang: string
): Promise<string> => {
  try {
    // If source language is set to auto, detect it first
    const sourceLanguage = fromLang === 'auto' 
      ? await detectLanguage(text)
      : fromLang;

    const prompt = `Translate the following text from ${sourceLanguage} to ${toLang}: "${text}"`;
    
    const response = await axios.post<TranslationResponse>(
      `${API_URL}?key=${GEMINI_API_KEY}`,
      {
        contents: [{
          parts: [{ text: prompt }]
        }]
      }
    );

    return response.data.candidates[0].content.parts[0].text;
  } catch (error) {
    if (axios.isAxiosError(error)) {
      throw new Error(error.response?.data?.error?.message || 'Translation failed');
    }
    throw error;
  }
};