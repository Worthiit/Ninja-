import { languages, languagesByRegion } from './languageData';

export { languages, languagesByRegion };

export const getAllLanguages = () => {
  return languages;
};