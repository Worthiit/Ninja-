import { CountryDialect } from '../types';

export const dialectsByCountry: Record<string, CountryDialect[]> = {
  en: [
    { country: 'US', name: 'American English', code: 'en-US' },
    { country: 'GB', name: 'British English', code: 'en-GB' },
    { country: 'AU', name: 'Australian English', code: 'en-AU' },
    { country: 'CA', name: 'Canadian English', code: 'en-CA' },
    { country: 'IN', name: 'Indian English', code: 'en-IN' }
  ],
  es: [
    { country: 'ES', name: 'Spanish (Spain)', code: 'es-ES' },
    { country: 'MX', name: 'Spanish (Mexico)', code: 'es-MX' },
    { country: 'AR', name: 'Spanish (Argentina)', code: 'es-AR' },
    { country: 'CO', name: 'Spanish (Colombia)', code: 'es-CO' }
  ],
  pt: [
    { country: 'PT', name: 'Portuguese (Portugal)', code: 'pt-PT' },
    { country: 'BR', name: 'Portuguese (Brazil)', code: 'pt-BR' }
  ],
  zh: [
    { country: 'CN', name: 'Chinese (Simplified)', code: 'zh-CN' },
    { country: 'TW', name: 'Chinese (Traditional)', code: 'zh-TW' },
    { country: 'HK', name: 'Chinese (Hong Kong)', code: 'zh-HK' }
  ],
  ar: [
    { country: 'SA', name: 'Arabic (Saudi Arabia)', code: 'ar-SA' },
    { country: 'EG', name: 'Arabic (Egypt)', code: 'ar-EG' },
    { country: 'MA', name: 'Arabic (Morocco)', code: 'ar-MA' }
  ]
};