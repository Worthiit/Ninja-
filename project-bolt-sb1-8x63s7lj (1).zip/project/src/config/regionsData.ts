import { LanguageRegion } from '../types';

export const languagesByRegion: Record<string, LanguageRegion[]> = {
  popular: [
    { code: 'en', name: 'English', countries: ['US', 'GB', 'AU', 'CA', 'IN'] },
    { code: 'es', name: 'Spanish', countries: ['ES', 'MX', 'AR', 'CO'] },
    { code: 'fr', name: 'French', countries: ['FR', 'CA', 'BE'] },
    { code: 'de', name: 'German', countries: ['DE', 'AT', 'CH'] }
  ],
  asian: [
    { code: 'zh', name: 'Chinese', countries: ['CN', 'TW', 'HK'] },
    { code: 'ja', name: 'Japanese', countries: ['JP'] },
    { code: 'ko', name: 'Korean', countries: ['KR'] },
    { code: 'vi', name: 'Vietnamese', countries: ['VN'] },
    { code: 'th', name: 'Thai', countries: ['TH'] }
  ],
  european: [
    { code: 'it', name: 'Italian', countries: ['IT'] },
    { code: 'pt', name: 'Portuguese', countries: ['PT', 'BR'] },
    { code: 'ru', name: 'Russian', countries: ['RU'] },
    { code: 'nl', name: 'Dutch', countries: ['NL', 'BE'] },
    { code: 'pl', name: 'Polish', countries: ['PL'] },
    { code: 'el', name: 'Greek', countries: ['GR'] }
  ],
  other: [
    { code: 'ar', name: 'Arabic', countries: ['SA', 'EG', 'MA'] },
    { code: 'hi', name: 'Hindi', countries: ['IN'] },
    { code: 'bn', name: 'Bengali', countries: ['BD', 'IN'] },
    { code: 'tr', name: 'Turkish', countries: ['TR'] }
  ]
};