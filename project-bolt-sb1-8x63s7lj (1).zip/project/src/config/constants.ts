export const GEMINI_API_KEY = 'AIzaSyBC8QQS8LOGhurWn8JmtqtFyF7WNvm1ueE';
export const API_URL = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent';