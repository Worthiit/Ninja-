export type Language = {
  code: string;
  name: string;
};

export type CountryDialect = {
  country: string;
  name: string;
  code: string;
};

export type LanguageRegion = {
  code: string;
  name: string;
  countries: string[];
};

export type TranslationResponse = {
  candidates: Array<{
    content: {
      parts: Array<{
        text: string;
      }>;
    };
  }>;
};

export type Theme = {
  name: string;
  colors: {
    primary: string;
    background: string;
    surface: string;
    text: string;
    textSecondary: string;
  };
};

export type ThemeContextType = {
  theme: Theme;
  setTheme: (theme: Theme) => void;
  isDark: boolean;
  toggleDark: () => void;
  isFloatingBubble: boolean;
  toggleFloatingBubble: () => void;
};