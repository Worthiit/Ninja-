import React, { useState } from 'react';
import { ArrowRightLeft, Loader2 } from 'lucide-react';
import { languages } from './config/languageData';
import { translateText } from './services/translationService';
import { LanguageSelector } from './components/LanguageSelector';
import { TextArea } from './components/TextArea';

function App() {
  const [fromLang, setFromLang] = useState('auto');
  const [toLang, setToLang] = useState('en');
  const [inputText, setInputText] = useState('');
  const [translatedText, setTranslatedText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSwapLanguages = () => {
    if (fromLang !== 'auto') {
      setFromLang(toLang);
      setToLang(fromLang);
      setInputText(translatedText);
      setTranslatedText(inputText);
    }
  };

  const handleTranslate = async () => {
    if (!inputText.trim()) return;

    setIsLoading(true);
    setError('');

    try {
      const result = await translateText(inputText, fromLang, toLang);
      setTranslatedText(result);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Translation failed');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-100 to-purple-100 py-8 px-4">
      <div className="max-w-3xl mx-auto">
        <h1 className="text-3xl font-bold text-center text-gray-800 mb-8">
          Language Translator
        </h1>

        <div className="bg-white rounded-lg shadow-lg p-6">
          <div className="grid grid-cols-[1fr,auto,1fr] gap-4 mb-6">
            <LanguageSelector
              value={fromLang}
              onChange={setFromLang}
              languages={languages}
              label="From Language"
            />

            <button
              onClick={handleSwapLanguages}
              disabled={fromLang === 'auto'}
              className="self-end mb-2 p-2 hover:bg-gray-100 rounded-full transition-colors
                       disabled:opacity-50 disabled:cursor-not-allowed"
              aria-label="Swap languages"
            >
              <ArrowRightLeft className="w-5 h-5" />
            </button>

            <LanguageSelector
              value={toLang}
              onChange={setToLang}
              languages={languages.filter(lang => lang.code !== 'auto')}
              label="To Language"
            />
          </div>

          <div className="space-y-4">
            <TextArea
              value={inputText}
              onChange={setInputText}
              placeholder="Enter text to translate..."
            />

            <button
              onClick={handleTranslate}
              disabled={isLoading || !inputText.trim()}
              className="w-full py-2 px-4 bg-indigo-600 text-white rounded-md
                         hover:bg-indigo-700 focus:outline-none focus:ring-2 
                         focus:ring-indigo-500 focus:ring-offset-2 disabled:opacity-50
                         disabled:cursor-not-allowed flex items-center justify-center"
            >
              {isLoading ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                'Translate'
              )}
            </button>

            <TextArea
              value={translatedText}
              onChange={setTranslatedText}
              placeholder="Translation will appear here..."
              readOnly
            />

            {error && (
              <p className="text-red-500 text-sm mt-2">{error}</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}